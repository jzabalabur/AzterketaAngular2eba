import { Component,OnInit } from '@angular/core';
import { MenusService } from 'src/app/services/menus.service';
import { Product } from 'src/app/model/product';
@Component({
  selector: 'app-factura',
  templateUrl: './factura.component.html',
  styleUrls: ['./factura.component.scss']
})
export class FacturaComponent implements OnInit{

  constructor() {   }
  ngOnInit(): void {   }

}
