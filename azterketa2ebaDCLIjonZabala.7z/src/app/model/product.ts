export class Product {
  constructor(
   public id:number,
   public orden: string,
   public titulo: string,
   public imagen: string,
   public precio: number,
    public basico: boolean,
   public especial:boolean

   ) { }

 }
